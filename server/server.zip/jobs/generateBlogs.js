const axios = require('axios');
const BlogPost = require('../models/BlogPost');
const generateBlogFromMovie = require('../utils/generateBlog');

const fetchTrendingMovies = async () => {
  try {
    const response = await axios.get('https://api.themoviedb.org/3/trending/movie/week', {
      headers: {
        Authorization: `Bearer ${process.env.TMDB_API_KEY}`,
      },
    });

    return response.data.results.map(movie => ({
      title: movie.title || movie.name,
      imageUrl: `https://image.tmdb.org/t/p/w500${movie.poster_path}`
    }));
  } catch (error) {
    console.error('Failed to fetch trending movies:', error.message);
    return [];
  }
};

const generateTrendingBlogs = async () => {
  const movies = await fetchTrendingMovies();

  for (const movie of movies.slice(0, 5)) {
    const exists = await BlogPost.findOne({ title: new RegExp(movie.title, 'i') });
    if (!exists) {
      try {
        await generateBlogFromMovie(movie.title, movie.imageUrl);
        console.log(`✅ Blog saved for: ${movie.title}`);
      } catch (err) {
        console.error(`❌ Failed to create blog for "${movie.title}":`, err.message);
      }
    } else {
      console.log(`⏩ Blog already exists for: ${movie.title}`);
    }
  }
};

module.exports = generateTrendingBlogs;
