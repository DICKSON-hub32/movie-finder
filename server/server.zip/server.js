const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const cron = require('node-cron');

const newsRoutes = require('./routes/news');
const trendingRoutes = require('./routes/trending');
const blogRoutes = require('./routes/blog');
const connectToMongoDB = require('./db/connect');
const generateTrendingBlogs = require('./jobs/generateBlogs'); // 🔥 Add this line



dotenv.config();
connectToMongoDB();

const app = express();
const PORT = process.env.PORT || 5000;

require('./scheduler');

app.use(cors());
app.use(express.json());
app.use('/api/news', newsRoutes);
app.use('/api/trending', trendingRoutes);
app.use('/api/blogs', blogRoutes);

app.get('/', (req, res) => {
  res.send('API is running...');
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});

// ⏰ Schedule the blog generation task to run every day at 9 AM
cron.schedule('0 9 * * *', async () => {
  console.log('📝 Auto-generating blogs from trending movies...');
  await generateTrendingBlogs();
});
