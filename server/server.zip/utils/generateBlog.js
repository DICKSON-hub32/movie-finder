const genai = require('@google/generative-ai');
const BlogPost = require('../models/BlogPost');
const genAI = new genai.GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const generateBlogFromMovie = async (movieTitle, imageUrl = '') => {
  const prompt = `Write a movie blog post about "${movieTitle}". Include:
- A catchy blog title (start with "Title: ")
- A short summary (start with "Summary: ")
- A full, fun, and engaging article (start with "Article: ")
- Watch advice (start with "Advice: ")
-Optimize for SEO`;

  const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' }); // Recommended model
  const result = await model.generateContent(prompt);
  const content = result.response.text();

  // Logging to debug AI output
  console.log('\n===== RAW AI CONTENT =====\n', content, '\n==========================\n');

  // Extract sections using Regex with safe defaults
  const title = content.match(/Title:\s*(.*)/i)?.[1]?.trim() || `Blog about ${movieTitle}`;
  const summary = content.match(/Summary:\s*([\s\S]*?)(?:\n?Article:|\n?Advice:)/i)?.[1]?.trim() || 'No summary provided.';
  const article = content.match(/Article:\s*([\s\S]*?)(?:\n?Advice:)/i)?.[1]?.trim() || 'No article generated.';  
  const advice = content.match(/Advice:\s*(.*)/i)?.[1]?.trim() || 'No advice provided.';

  const cleanText = (text) => {
    if (!text) return '';
    return text
      .replace(/^#+\s*/gm, '')         // Remove markdown headers like # or ##
      .replace(/\*/g, '')              // Remove all asterisks (italic or bullet styling)
      .trim();                         // Remove leading/trailing whitespace
  };
  

  console.log('🧩 Extracted Fields:', { title, summary, article, advice });


  const newBlog = new BlogPost({
    title: cleanText(title),
    summary: cleanText(summary),
    article: cleanText(article),
    advice: cleanText(advice),
    imageUrl,
  });

  await newBlog.save();
  return newBlog;
};

module.exports = generateBlogFromMovie;
